#ifndef _adc_H
#define _adc_H

#include "system.h"


extern __IO u16 ADC_ConvertedValue[2];

void ADCx_Init(void);



#endif
