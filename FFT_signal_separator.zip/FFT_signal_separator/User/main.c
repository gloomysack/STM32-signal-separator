#include "system.h"
#include "SysTick.h"
#include "led.h"
#include "usart.h"
#include "adc.h"
#include "my_dds.h"
#include "arm_math.h"
#include "arm_const_structs.h"

#define FFT_LEN 4096                 // FFT����
#define SAMPLING_FREQ 200000         // ����Ƶ��
#define MIN_FREQ_THRESHOLD 50        // ��СƵ����ֵ
#define MAX_FREQ_THRESHOLD 100000    // ���Ƶ����ֵ

extern uint32_t sample_count;
float adc_samples[FFT_LEN];        // �洢ADC��������
float fft_input[FFT_LEN * 2];      // FFT��������
float fft_output[FFT_LEN];         // FFT�������
float fft_magnitude[FFT_LEN / 2];  // ���߷�����
float hann_window[FFT_LEN];        // ����������ϵ��

// Ƶ�ʷ����ṹ��
typedef struct {
    float magnitude;  // ����
    int index;        // Ƶ������
    float frequency;  // Ƶ��ֵ
} FrequencyComponent;

// ����������
void init_hanning_window(void) 
{
    for (int i = 0; i < FFT_LEN; i++) {
        hann_window[i] = 0.5 * (1 - cosf(2.0f * PI * i / (FFT_LEN - 1)));
    }
}

// ��ӡƵ����Ϣ
void print_spectrum_info(FrequencyComponent first, FrequencyComponent second) {
    float frequency_resolution = (float)SAMPLING_FREQ / FFT_LEN;
    
    printf("====================\r\n\r\n");
    printf("����Ƶ��: %d Hz\r\n", SAMPLING_FREQ);
    printf("Ƶ�ʷֱ���: %.2f Hz\r\n", frequency_resolution);
    printf("���Ƶ�ʷ���: %.2f Hz, ����: %.4f\r\n", first.frequency, first.magnitude);
    printf("�ڶ���Ƶ�ʷ���: %.2f Hz, ����: %.4f\r\n", second.frequency, second.magnitude);
    printf("====================\r\n\r\n");
}

// �����߲�ֵƵ�ʹ���
float parabolic_interpolation(int peak_index) 
	{
    if (peak_index <= 0 || peak_index >= (FFT_LEN/2 - 1)) {
        return (float)peak_index;
    }
    
    float y0 = fft_magnitude[peak_index-1];
    float y1 = fft_magnitude[peak_index];
    float y2 = fft_magnitude[peak_index+1];
    float delta = 0.5f * (y0 - y2) / (y0 - 2*y1 + y2);
    return (float)peak_index + delta;
}

// ������������Ƶ�ʷ���
void find_top_two_frequencies_improved(FrequencyComponent *first, FrequencyComponent *second) 
{
    float frequency_resolution = (float)SAMPLING_FREQ / FFT_LEN;
    first->magnitude = 0;
    first->index = 0;
    second->magnitude = 0;
    second->index = 0;
    
    // ���㵥�߷����ײ��ҵ�������������
    for (int i = 0; i < FFT_LEN / 2; i++) {
        float freq = i * frequency_resolution;
        if (freq < MIN_FREQ_THRESHOLD || freq > MAX_FREQ_THRESHOLD) {
            continue;
        }
        if (i == 0) {
            fft_magnitude[i] = fft_output[i] / FFT_LEN;
        } else {
            fft_magnitude[i] = 2.0f * fft_output[i] / FFT_LEN;
        }
        
        // ����������������
        if (fft_magnitude[i] > first->magnitude) {
            second->magnitude = first->magnitude;
            second->index = first->index;
            first->magnitude = fft_magnitude[i];
            first->index = i;
        } else if (fft_magnitude[i] > second->magnitude) {
            second->magnitude = fft_magnitude[i];
            second->index = i;
        }
    }
    float interpolated_index1 = parabolic_interpolation(first->index);
    float interpolated_index2 = parabolic_interpolation(second->index);
    first->frequency = interpolated_index1 * frequency_resolution;
    second->frequency = interpolated_index2 * frequency_resolution;
}

int main()
{   
    u8 i = 0;
		sample_count = 0;
    float vol;
    FrequencyComponent first, second;
    SysTick_Init(168);
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    LED_Init();
    USART1_Init(115200);
    ADCx_Init();	
    AD9959_Init();
    arm_cfft_radix4_instance_f32 scfft;
    arm_cfft_radix4_init_f32(&scfft, FFT_LEN, 0, 1);
    init_hanning_window();
    while(1)
    {
				i++;
			
        for (int i = 0; i < FFT_LEN; i++) {
            adc_samples[i] = (float)ADC_ConvertedValue[0] * (3.3f / 4096.0f);
            adc_samples[i] *= hann_window[i];
            delay_us(1000000 / SAMPLING_FREQ);
        }				    
        for (int i = 0; i < FFT_LEN; i++) {
            fft_input[i * 2] = adc_samples[i];
            fft_input[i * 2 + 1] = 0.0f; 
        }
				
					if (sample_count >= FFT_LEN)
					{
            sample_count = 0;
            for (int i = 0; i < FFT_LEN; i++) {
                adc_samples[i] *= hann_window[i]; 
            }
            
            for (int i = 0; i < FFT_LEN; i++) {
                fft_input[i * 2] = adc_samples[i];      // ʵ��
                fft_input[i * 2 + 1] = 0.0f;            // �鲿
            }
     
        arm_cfft_radix4_f32(&scfft, fft_input);
        arm_cmplx_mag_f32(fft_input, fft_output, FFT_LEN);
        find_top_two_frequencies_improved(&first, &second);
        
			}	
					
						if (i % 500 == 0) 
					 {		  
            if(first.frequency > MIN_FREQ_THRESHOLD && first.frequency < MAX_FREQ_THRESHOLD) {
                AD9959_Set_Fre(CH0, (u32)first.frequency);
                AD9959_Set_Amp(CH0, 1023);
                AD9959_Set_Phase(CH0, 0);
                printf("CH0����Ƶ��Ϊ%.2fHz\r\n", first.frequency);
            } 
						
            if(second.frequency > MIN_FREQ_THRESHOLD && second.frequency < MAX_FREQ_THRESHOLD) 
					 {
                AD9959_Set_Fre(CH1, (u32)second.frequency);
                AD9959_Set_Amp(CH1, 1023);
                AD9959_Set_Phase(CH1, 0);
                printf("CH1����Ƶ��Ϊ%.2fHz\r\n", second.frequency);
            }          
            IO_Update();            
            print_spectrum_info(first, second);
						delay_ms(2000);
        }
    }
}    